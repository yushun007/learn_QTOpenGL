//
// Created by 禹舜 on 2023/12/15.
//

#include <unistd.h>
#include "gl_window.hpp"
#include "opencv2/core.hpp"
#include "opencv2/highgui.hpp"
#include "iostream"
#include "QKeyEvent"

float vertices[] = {
        // positions          // colors           // texture coords
        0.5f,  0.5f, 0.0f,   1.0f, 0.0f, 0.0f,   1.0f, 1.0f, // top right
        0.5f, -0.5f, 0.0f,   0.0f, 1.0f, 0.0f,   1.0f, 0.0f, // bottom right
        -0.5f, -0.5f, 0.0f,   0.0f, 0.0f, 1.0f,   0.0f, 0.0f, // bottom left
        -0.5f,  0.5f, 0.0f,   1.0f, 1.0f, 0.0f,   0.0f, 1.0f  // top left
};
unsigned int indices[] = {
        0, 1, 3, // first triangle
        1, 2, 3  // second triangle
};
unsigned int VAO,VBO,VEO;
glWindow::glWindow(QWidget *parent): QOpenGLWidget(parent) {

}

void glWindow::initializeGL() {
    initializeOpenGLFunctions();
    QOpenGLShaderProgram program;
    program.create();
    program.addShaderFromSourceFile(QOpenGLShader::Vertex,"/Volumes/develop/develop/qt_opengl/texture/4.1.texture.vs");
    program.addShaderFromSourceFile(QOpenGLShader::Fragment,"/Volumes/develop/develop/qt_opengl/texture/4.1.texture.fs");
    program.link();
    program_id = program.programId();

    glGenVertexArrays(1,&VAO);
    glGenBuffers(1,&VBO);
    glGenBuffers(1,&VEO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER,VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(vertices),vertices,GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,VEO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,sizeof(indices),indices,GL_STATIC_DRAW);

    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(float)*8,(void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(float)*8,(void*)(sizeof(float)*3));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(float)*8,(void*)(sizeof(float)*6));
    glEnableVertexAttribArray(2);

//    glGenTextures(1,&texture);
//    glBindTexture(GL_TEXTURE_2D,texture);
//    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
//    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
//
//    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
//    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
//    cv::Mat img;
//    img = cv::imread("/Volumes/develop/libs/LearnOpenGL/resources/textures/container.jpg");
//    int width = img.cols;
//    int height = img.rows;
//    int channels = img.channels();
//    glTexImage2D(GL_TEXTURE_2D,0,GL_RGB,width,height,0,GL_RGB,GL_UNSIGNED_BYTE,img.data);
//    glGenerateMipmap(GL_TEXTURE_2D);
}

void glWindow::resizeGL(int w, int h) {
    glViewport(0,0,w,h);
}

void glWindow::paintGL() {
    glClearColor(0.2,0.8,0,1);
    glUseProgram(program_id);
//    glBindTexture(GL_TEXTURE_2D,texture);
    glBindVertexArray(VAO);
    glDrawElements(GL_TRIANGLES,6,GL_UNSIGNED_INT,(void*)0);
}

void glWindow::keyPressEvent(QKeyEvent *event) {
    if(event->key() == Qt::Key_Escape){
        exit(0);
    }
}
