//
// Created by 禹舜 on 2023/12/15.
//

#ifndef TEXTURE_GL_WINDOW_HPP
#define TEXTURE_GL_WINDOW_HPP

#include "QOpenGLWidget"
#include "QOpenGLFunctions_4_1_Core"
#include "QOpenGLShaderProgram"

class glWindow: public QOpenGLWidget, protected QOpenGLFunctions_4_1_Core{
    Q_OBJECT

protected:
    void initializeGL() override;

    void resizeGL(int w, int h) override;

    void paintGL() override;

    void keyPressEvent(QKeyEvent *event) override;

public:
    glWindow(QWidget* parent= nullptr);
private:
    unsigned int program_id;
    unsigned int texture;
};


#endif //TEXTURE_GL_WINDOW_HPP
