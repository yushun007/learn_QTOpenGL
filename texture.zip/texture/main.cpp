#include <QApplication>
#include <QPushButton>
#include "QSurfaceFormat"
#include "gl_window.hpp"
#include "opencv2/core.hpp"
#include "opencv2/highgui.hpp"

int main(int argc, char *argv[]) {
    QSurfaceFormat format;
    format.setVersion(4,1);
    format.setProfile(QSurfaceFormat::CoreProfile);
    QSurfaceFormat::setDefaultFormat(format);
    QApplication a(argc, argv);
    glWindow window;
    window.setMinimumSize(800,800);
    window.show();
    return QApplication::exec();
}
